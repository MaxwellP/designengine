YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "API",
        "Action",
        "Card",
        "Event",
        "GameDescription",
        "Gamestate",
        "Helpers",
        "Phase",
        "Player",
        "Zone"
    ],
    "modules": [],
    "allModules": []
} };
});